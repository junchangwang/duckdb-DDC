#include "combit_adapter.h"

std::unordered_map<std::string, std::vector<ComBit>> g_combit_bitmaps;

ComBit ibis_to_combit(ibis::bitvector* btv) {
    // Make a copy and decompress to get all literal WAH words
    ibis::bitvector tmp;
    tmp.copy(*btv);
    tmp.decompress();

    size_t total_bits = tmp.size();
    std::vector<bool> bits(total_bits, false);

    size_t pos = 0;

    // Iterate decompressed WAH literal words
    // After decompress(), each word in m_vec is a literal:
    //   bit 31 = 0 (literal marker), bits 30..0 = 31 data bits (MSB first)
    for (auto it = tmp.m_vec.begin(); it != tmp.m_vec.end(); ++it) {
        uint32_t word = *it;
        for (int j = 30; j >= 0 && pos < total_bits; j--) {
            if ((word >> j) & 1) {
                bits[pos] = true;
            }
            pos++;
        }
    }

    // Handle the active (trailing partial) word
    for (int j = static_cast<int>(tmp.active.nbits) - 1; j >= 0 && pos < total_bits; j--) {
        if ((tmp.active.val >> j) & 1) {
            bits[pos] = true;
        }
        pos++;
    }

    return ComBit::compress(bits);
}

void convert_rabit_to_combit(const std::string& name, rabit::Rabit* rabit) {
    auto start = std::chrono::high_resolution_clock::now();

    int n = rabit->num_btvs;
    std::vector<ComBit> combits;
    combits.reserve(n);

    for (int i = 0; i < n; i++) {
        if (rabit->Btvs[i] && rabit->Btvs[i]->btv) {
            combits.push_back(ibis_to_combit(rabit->Btvs[i]->btv));
        } else {
            combits.emplace_back(); // empty ComBit placeholder
        }
    }

    g_combit_bitmaps[name] = std::move(combits);

    auto end = std::chrono::high_resolution_clock::now();
    std::cout << "ComBit conversion for " << name << ": "
              << std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count()
              << "ms (" << n << " bitvectors)" << std::endl;
}

const ComBit& get_combit(const std::string& name, int value) {
    return g_combit_bitmaps.at(name).at(value);
}

void GetRowidsComBit(const ComBit& combit_res, std::vector<int64_t>* row_ids) {
    // Reserve space based on popcount to avoid reallocations
    row_ids->reserve(combit_res.popcount());

    size_t global_offset = 0;
    for (size_t seg_idx = 0; seg_idx < combit_res.num_segments(); seg_idx++) {
        const auto& seg = combit_res.segment(seg_idx);
        // After AND/OR/XOR, result is fully expanded:
        //   use_l3_ = false, all words are literals
        //   L1 contains ALL bytes of the bitvector in order
        const uint8_t* data = seg.l1_literal_data();
        size_t num_bytes = seg.num_literals();
        size_t seg_bits = seg.bit_count();

        for (size_t i = 0; i < num_bytes; i++) {
            uint8_t byte = data[i];
            if (byte == 0) continue;  // fast skip zero bytes

            size_t base = global_offset + i * 8;
            // Bits are stored MSB-first (big-endian within each byte)
            // Byte bit 7 = original position base+0, bit 6 = base+1, etc.
            if (byte & 0x80) row_ids->push_back(static_cast<int64_t>(base + 0));
            if (byte & 0x40) row_ids->push_back(static_cast<int64_t>(base + 1));
            if (byte & 0x20) row_ids->push_back(static_cast<int64_t>(base + 2));
            if (byte & 0x10) row_ids->push_back(static_cast<int64_t>(base + 3));
            if (byte & 0x08) row_ids->push_back(static_cast<int64_t>(base + 4));
            if (byte & 0x04) row_ids->push_back(static_cast<int64_t>(base + 5));
            if (byte & 0x02) row_ids->push_back(static_cast<int64_t>(base + 6));
            if (byte & 0x01) row_ids->push_back(static_cast<int64_t>(base + 7));
        }

        global_offset += seg_bits;
    }
}
