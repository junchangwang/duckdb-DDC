#pragma once

#include "combit/include/combit.h"
#include "bitmaps/rabit/table.h"

#include <string>
#include <vector>
#include <unordered_map>
#include <iostream>
#include <chrono>
#include <cstdint>
#include <cstring>

// Global storage for ComBit versions of bitmaps
// Key: bitmap name (e.g., "shipmode"), Value: vector of ComBit per cardinality value
extern std::unordered_map<std::string, std::vector<ComBit>> g_combit_bitmaps;

// Convert all equality-encoded bitvectors in a Rabit index to ComBit format
void convert_rabit_to_combit(const std::string& name, rabit::Rabit* rabit);

// Get a ComBit bitvector by name and value index
const ComBit& get_combit(const std::string& name, int value);

// Convert a single ibis::bitvector to ComBit format
ComBit ibis_to_combit(ibis::bitvector* btv);

// Fast row ID extraction from ComBit result (avoids full decompression)
void GetRowidsComBit(const ComBit& combit_res, std::vector<int64_t>* row_ids);
